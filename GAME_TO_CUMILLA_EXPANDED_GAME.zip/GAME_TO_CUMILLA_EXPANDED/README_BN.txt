GAME TO CUMILLA — Expanded Browser Game Package

প্রকাশ করার নিয়ম:
1) এই ZIP Extract করুন।
2) Cloudflare Dashboard > Workers & Pages > Create application > Pages > Direct Upload নির্বাচন করুন।
3) Extract করা ফোল্ডারের ভেতরের index.html, manifest.webmanifest, sw.js, icon.svg ফাইলগুলো একই root folder থেকে আপলোড করুন।
4) Deploy করুন।

ফিচার:
- মোবাইল টাচ ও কম্পিউটার কীবোর্ড কন্ট্রোল
- ঢাকা থেকে দূরের শহর পর্যন্ত প্রগ্রেস
- ভার্চুয়াল টোল গেট (৳100; বাস্তব টাকা নয়)
- গেমের কয়েন সংগ্রহ, ট্রাফিক, জ্বালানি, স্কোর
- Share এবং PWA install support

সীমাবদ্ধতা:
এটি একটি 2D browser game prototype; বাস্তবসম্মত 3D Unity গেম নয়। APK ফাইল এই ZIP-এ নেই। PWA install Chrome-এর Add to Home Screen/Install সুবিধা; এটি APK নয়। গেমের দূরত্ব/টোল/শহরগুলো কাল্পনিক gameplay progression, বাস্তব GPS/মানচিত্র বা আসল টোল পেমেন্ট নয়।
